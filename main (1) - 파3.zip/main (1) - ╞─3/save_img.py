import cv2
import os

def save_image(frame, count):
    image_name = f"./imgs/image_{count}.jpg"
    cv2.imwrite(image_name, frame)
    print(f"{image_name} 저장 완료")

def main():
    # 웹캠 열기
    cap = cv2.VideoCapture(0)

    # 이미지 저장을 위한 변수 초기화
    count = 0

    while True:
        # 프레임 읽기
        ret, frame = cap.read()

        # 프레임이 제대로 읽혔을 경우에만 동작
        if ret:
            # 화면에 프레임 출력
            cv2.imshow('Webcam', frame)

            # 's' 버튼을 누르면 이미지 저장
            if cv2.waitKey(1) & 0xFF == ord('s'):
                save_image(frame, count)
                count += 1

            # 'q' 버튼을 누르면 종료
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    # 웹캠 해제 및 윈도우 창 닫기
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
