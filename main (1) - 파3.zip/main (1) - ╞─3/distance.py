import numpy as np
import cv2
import glob
import os


theta1 = 0
theta2 = 0 
closest_point = None
center_x = 0  # 초기값 설정
center_y = 0  # 초기값 설정

def smooth_image(image, kernel_size=(5, 5), sigma=0):
    blurred = cv2.GaussianBlur(image, kernel_size, sigma)
    return blurred

def find_distance(condition, cameraMatrix, tvec, rvec, frame):

    # 이미지 스무딩
    smoothed_frame = smooth_image(frame, kernel_size=(5, 5), sigma=0)

    # 이미지 전처리
    hsv = cv2.cvtColor(smoothed_frame, cv2.COLOR_BGR2HSV)

    if condition == 0: # 홀컵 색상 범위 설정
        lower_color = np.array([81, 80, 139])
        upper_color = np.array([102, 102, 153])

    elif condition == 1: # 공 색상 범위 설정
        lower_color = np.array([59, 108, 199])
        upper_color = np.array([189, 128, 228])

    # 색상 영역 추출
    yellow_mask = cv2.inRange(hsv, lower_color, upper_color)

    # 면적 기준 크기 필터링
    min_block_area = 1000  # 최소 면적 크기 설정 (조정 가능)

    # 노란색 컨투어 찾기
    contours, _ = cv2.findContours(yellow_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    closest_distance = float('inf')
    closest_point = None
    largest_area = 0  # 가장 큰 면적 초기화

    center_x = 0
    center_y = 0
    for contour in contours:
        # 컨투어의 면적 계산
        area = cv2.contourArea(contour)

        if area > min_block_area and area > largest_area:
            largest_area = area

            # 노란색 컨투어의 중심 좌표 계산
            M = cv2.moments(contour)
            center_x = int(M['m10'] / M['m00'])
            center_y = int(M['m01'] / M['m00'])

            # 가장 큰 면적을 가진 노란색 블록 선택
            closest_point = (center_x, center_y)


    # 결과 출력
    if closest_point is not None:
        cv2.circle(smoothed_frame, closest_point, 5, (0, 0, 255), -1)

    #     print("Closest Yellow Block Coordinate:", closest_point)

    ########## 3d 변환
    u = (center_x - cameraMatrix[0, 2])/ cameraMatrix[0, 0]
    v = (center_y - cameraMatrix[1, 2])/ cameraMatrix[1, 1]

    # transposed_rvec = np.transpose(R)'
    R, _ = cv2.Rodrigues(rvec)
    transposed_rvec = np.transpose(R)

    # print("transposed_rvec")
    # print(transposed_rvec)
    cc = np.zeros((3, 1))
    # print("cc : ")
    # print(cc)
    pc = np.vstack((u, v, 1))
    pw = np.matmul(transposed_rvec, (pc - tvec))
    cw = np.matmul(transposed_rvec, (cc - tvec))
    # print("pw : ")
    # print(pw)
    # print("cc - tvec")
    # print(cc - tvec)
    # print("transposed_rvec", transposed_rvec)
    # cw = np.squeeze(cw)  # cw의 shape을 (3,)으로 조정
    # print("cw : ")
    # print(cw)
    k = -cw[2] / (pw[2] - cw[2])
    # print("cw[2] : ")
    # print(cw[2])
    # print("k")
    # print(k)
    p = cw + k * (pw - cw)
    # print("coordinate to yellow block : ")
    # print(p)
    # ...

    p_squared_sum = np.sum(np.square(p))
    p_sum_sqrt = np.sqrt(p_squared_sum)
    p_squared_sum_cm = p_sum_sqrt / 10
    if condition == 0: # 홀컵 색상 범위 설정
        print("dis to holecup:", p_squared_sum_cm) 
    elif condition == 1: # 홀컵 색상 범위 설정
        print("dis to ball:", p_squared_sum_cm) 
    p_squared_sum_cm_text = "dis: {:.2f} cm".format(p_squared_sum_cm)
    text_position = (10, 70)
    text_color = (255, 0, 0)  
    text_font = cv2.FONT_HERSHEY_SIMPLEX
    text_scale = 1.5
    text_thickness = 2

    cv2.putText(frame, p_squared_sum_cm_text, text_position, text_font, text_scale, text_color, text_thickness)
    # latest_p = p_squared_sum_cm_text
# ...

    # # 'q' 키를 누르면 종료
    # if cv2.waitKey(1) & 0xFF == ord('q'):
    #     break

    # # 웹캠 해제
    # cap.release()
    # cv2.destroyAllWindows()

    return True, p_squared_sum_cm

def goal_coord(r, theta):
    goal_x = r * np.cos(theta)
    goal_y = r * np.sin(theta)
    return goal_x, goal_y

def transform_point(homography_matrix, center_x, center_y):
    # 입력된 center_x, center_y를 평면 2의 좌표로 변환
    input_point = np.array([[center_x, center_y]], dtype=np.float32)
    transformed_point = cv2.perspectiveTransform(input_point.reshape(-1, 1, 2), homography_matrix)

    # 변환된 좌표를 반환
    return transformed_point[0][0]
