from detect import Detector
from minirobot_serial import MinirobotSerial
import cv2
import time

def run():
        # detector = Detector(isDebug=True, W_View_size=640, H_View_size=480, FPS=30)
        minirobot_serial = MinirobotSerial()
       #minirobot_serial.check_flag(32, 230)
        #minirobot_serial.walk_forward(15)
        
        #time.sleep(2)
        
        
        print("output", minirobot_serial.serial_port.out_waiting)
        print("input", minirobot_serial.serial_port.inWaiting())
        minirobot_serial.check_flag(24, 230)
        print("output", minirobot_serial.serial_port.out_waiting)
        print("input", minirobot_serial.serial_port.inWaiting())
        
        minirobot_serial.RX_data()
    
    
        # minirobot_serial.check_flag(42, 230)
        
        '''
        try:
            while True:
                state = detector.detect_ball()
                print(f"({detector.center_x_ball}, {detector.center_y_ball})")
        except:
            minirobot_serial.check_flag(38, 230)
        '''
        
if __name__ == "__main__":
    run()
