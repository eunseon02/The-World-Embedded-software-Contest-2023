import cv2
import numpy as np
import time
import datetime

def nothing(x):
    pass

def get_hsv_yuv(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        yuv = cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)

        hsv_value = hsv[y, x]
        yuv_value = yuv[y, x]

        print("Clicked Point HSV:", hsv_value,"Clicked Point YUV:", yuv_value)

def save(file_path, values):
    
    now = datetime.datetime.now()
    
    with open(file_path, 'a') as f:
        f.write(f'---------- {now} ----------\n')
        
        print(values)
        
        if values[0] == 0:
            f.write("ball: ")
        else:
            f.write("pole: ")
        
        f.write(f"({values[1]}, {values[2]}, {values[3]}), " + \
                f"({values[4]}, {values[5]}, {values[6]}), " + \
                f"({values[7]}, {values[8]}, {values[9]}), " + \
                f"({values[10]}, {values[11]}, {values[12]})\n\n")
        
    print(file_path, " save!!")

# 캠에서 이미지를 받아올 캡처 객체 생성
W_View_size = 640
H_View_size = 480
FPS = 30

image_folder_path = 'image_folder'  # 폴더 경로를 수정해주세요
image_files = os.listdir(image_folder_path)

cap = cv2.VideoCapture(0)

cap.set(3, W_View_size)
cap.set(4, H_View_size)
cap.set(5, FPS)
time.sleep(0.5)

cv2.namedWindow('origin frame')
cv2.namedWindow('HSV frame')
cv2.namedWindow('YUV frame')
cv2.namedWindow('Combined frame')

margin = 100
width_track_bar = 300
height_track_bar = 100

black_image = np.zeros((int(H_View_size/2), int(W_View_size/2), 3), np.uint8)
cv2.imshow('HSV Track Bar', black_image)
cv2.imshow('YUV Track Bar', black_image)

cv2.moveWindow('origin frame', margin, margin)
cv2.moveWindow('HSV frame', width_track_bar + margin, margin)
cv2.moveWindow('YUV frame', (width_track_bar + margin)*2, margin)
cv2.moveWindow('Combined frame', (width_track_bar + margin)*3, margin)

cv2.setMouseCallback('origin frame', get_hsv_yuv)

# -----------
cv2.namedWindow('HSV Track Bar')
cv2.namedWindow('YUV Track Bar')
cv2.namedWindow('ID Bar')

black_image = np.zeros((10, width_track_bar, 3), np.uint8)
cv2.imshow('HSV Track Bar', black_image)
cv2.imshow('YUV Track Bar', black_image)
cv2.imshow('ID Bar', black_image)

cv2.createTrackbar('Max HSV H', 'HSV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min HSV H', 'HSV Track Bar', 100, 255, nothing)
cv2.createTrackbar('Max HSV S', 'HSV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min HSV S', 'HSV Track Bar', 100, 255, nothing)
cv2.createTrackbar('Max HSV V', 'HSV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min HSV V', 'HSV Track Bar', 100, 255, nothing)

cv2.createTrackbar('Max YUV Y', 'YUV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min YUV Y', 'YUV Track Bar', 100, 255, nothing)
cv2.createTrackbar('Max YUV U', 'YUV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min YUV U', 'YUV Track Bar', 100, 255, nothing)
cv2.createTrackbar('Max YUV V', 'YUV Track Bar', 255, 255, nothing)
cv2.createTrackbar('Min YUV V', 'YUV Track Bar', 100, 255, nothing)

cv2.createTrackbar('ID', 'ID Bar', 0, 2, nothing)

cv2.resizeWindow(winname='HSV Track Bar', width=width_track_bar, height=height_track_bar)
cv2.resizeWindow(winname='YUV Track Bar', width=width_track_bar, height=height_track_bar)

cv2.moveWindow('HSV Track Bar', margin, H_View_size + margin)
cv2.moveWindow('YUV Track Bar', width_track_bar + margin*2, H_View_size + margin)
cv2.moveWindow('ID Bar', width_track_bar + margin*3, H_View_size + margin)

while True:
    # 캠에서 프레임 읽기
    _, frame = cap.read()
    
    
    
    
    # ---------
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    yuv = cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)

    # ---------
    max_h = cv2.getTrackbarPos('Max HSV H', 'HSV Track Bar')
    min_h = cv2.getTrackbarPos('Min HSV H', 'HSV Track Bar')
    max_s = cv2.getTrackbarPos('Max HSV S', 'HSV Track Bar')
    min_s = cv2.getTrackbarPos('Min HSV S', 'HSV Track Bar')
    max_hsv_v = cv2.getTrackbarPos('Max HSV V', 'HSV Track Bar')
    min_hsv_v = cv2.getTrackbarPos('Min HSV V', 'HSV Track Bar')
    
    max_y = cv2.getTrackbarPos('Max YUV Y', 'YUV Track Bar')
    min_y = cv2.getTrackbarPos('Min YUV Y', 'YUV Track Bar')
    max_u = cv2.getTrackbarPos('Max YUV U', 'YUV Track Bar')
    min_u = cv2.getTrackbarPos('Min YUV U', 'YUV Track Bar')
    max_yuv_v = cv2.getTrackbarPos('Max YUV V', 'YUV Track Bar')
    min_yuv_v = cv2.getTrackbarPos('Min YUV V', 'YUV Track Bar')
    
    id = cv2.getTrackbarPos('ID', 'ID Bar')

    # ---------
    lower_hsv = np.array([min_h, min_s, min_hsv_v])
    upper_hsv = np.array([max_h, max_s, max_hsv_v])

    lower_yuv = np.array([min_y, min_u, min_yuv_v])
    upper_yuv = np.array([max_y, max_u, max_yuv_v])
    # ---------
    
    # ---------
    mask_hsv = cv2.inRange(hsv, lower_hsv, upper_hsv)
    mask_yuv = cv2.inRange(yuv, lower_yuv, upper_yuv)
    mask_combined = cv2.bitwise_and(mask_hsv, mask_yuv)
    # ---------
    
    cnts_hsv = cv2.findContours(mask_hsv, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    cnts_yuv = cv2.findContours(mask_yuv, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    cnts_com = cv2.findContours(mask_combined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    
    black_image_hsv = np.zeros((H_View_size, W_View_size, 3), np.uint8)
    black_image_yuv = np.zeros((H_View_size, W_View_size, 3), np.uint8)
    black_image_com = np.zeros((H_View_size, W_View_size, 3), np.uint8)
    
    cv2.drawContours(black_image_hsv, cnts_hsv, -1, (255, 255, 255), 1)
    cv2.drawContours(black_image_yuv, cnts_yuv, -1, (255, 255, 255), 1)
    cv2.drawContours(black_image_com, cnts_com, -1, (255, 255, 255), 1)

    frame = cv2.resize(frame, dsize=(0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_LINEAR)
    black_image_hsv = cv2.resize(black_image_hsv, dsize=(0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_LINEAR)
    black_image_yuv = cv2.resize(black_image_yuv, dsize=(0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_LINEAR)
    black_image_com = cv2.resize(black_image_com, dsize=(0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_LINEAR)
    
    # 이미지 출력
    cv2.imshow('origin frame', frame)
    cv2.imshow('HSV frame', black_image_hsv)
    cv2.imshow('YUV frame', black_image_yuv)
    cv2.imshow('Combined frame', black_image_com)

    # 'q' 키를 누르면 종료
    key = cv2.waitKey(1)
    
    if key & 0xFF == ord('q'):
        break
    elif key & 0xFF == ord('s'):
        save(file_path='color_space.txt', values=[id, min_h, min_s, min_hsv_v, max_h, max_s, max_hsv_v, min_y, min_u, min_yuv_v, max_y, max_u, max_yuv_v])

# 캡처 객체와 윈도우 종료
cap.release()
cv2.destroyAllWindows()
