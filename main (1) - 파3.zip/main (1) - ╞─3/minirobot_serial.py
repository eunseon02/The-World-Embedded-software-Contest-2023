import serial
import time
import traceback
import numpy as np

class MinirobotSerial():
    def __init__(self) -> None:
        
        BPS =  4800  # 4800,9600,14400, 19200,28800, 57600, 115200
        self.serial_port = serial.Serial('/dev/ttyS0', BPS, timeout=0.01)
        self.serial_port.flush() # serial cls
        
        self.flag_get_head_angle = 37
        self.left_rotation_head_data = 33
        self.right_rotation_head_data = 34
        self.left_init_rotation_head_data = 23
        self.rigth_init_rotation_head_data = 35
        self.down_rotation_head_data = 36
        self.rotation_body_data = {"left_turn_5": 1, "left_turn_10": 4, "left_turn_20": 8, "left_turn_45": 22, "left_turn_60": 25,
                                   "right_turn_5": 3, "right_turn_10": 6, "right_turn_20": 9, "right_turn_45": 24, "right_turn_60": 19}
        
    #-----------------------------------------------
    def TX_data(self, one_byte) -> None:  # one_byte= 0~255

        # self.serial_port.flushOutput()
        
        #ser.write(chr(int(one_byte)))          #python2.7
        #self.serial_port.flushOutput()
        #time.sleep(1)
        
        # print("Tx_data:", one_byte)
        
        if self.serial_port.out_waiting > 0:
            self.serial_port.flushOutput()
        
        # print("self.serial_port.out_waiting", self.serial_port.out_waiting)
        self.serial_port.write(serial.to_bytes([one_byte]))  #python3

    #-----------------------------------------------
    def RX_data(self) -> int:
        
        # print("self.serial_port.inWaiting() ", self.serial_port.inWaiting())
        if self.serial_port.inWaiting() > 0:
            result = self.serial_port.read(1)
            RX = ord(result)
            # print(RX)
            return RX
        else:
            return 0

    #-----------------------------------------------
    def check_flag(self, tx_data, rx_data):
        
        
        self.TX_data(tx_data)
        
        while True:
            data = 0
            
            data = self.RX_data()
            if data == rx_data:
                break
            
            # print(f"Check Data: tx_data({tx_data}), rx_data({rx_data})...")

        # print("!-----Checked Data-----!")
    
    #-----------------------------------------------
    def RX_start_flag(self) -> bool:
        
        try:
            data = self.RX_data()
            
            # print(f"data: {data}")
            time.sleep(0.1)
            if data == 5:
                return True
            else:
                return False
                    
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            return False

    #-----------------------------------------------
    def get_angle_head(self) -> int:
        
        try:
            while True:
                data = 0
                self.TX_data(self.flag_get_head_angle) # 37
                
                data = self.RX_data()
                if data == 195:
                    break
                
                # print(f"tx_data: {self.flag_get_head_angle}, data: {data}")
            
            while True:
                angle = 0
                self.TX_data(200)
                angle = self.RX_data()
                if angle != 0 and angle != 195 and angle != 230:
                    # print("break angle")
                    break
                
                # print(f"tx_data: {200}, angle: {angle}")
            # print(f"!!!!!!!!!!!!!!!angle: {angle}!!!!!!!!!!!!!!")    
            
            # self.check_flag(self.flag_get_head_angle, 380)
            
            # self.check_flag(777, 380)
            
            return angle - 100
            
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            return 0

    #-----------------------------------------------
    def rotation_head(self, swing_flag) -> None:
        
        try:
            #self.serial_port.flush()
            angle_head = self.get_angle_head()
            print("swing_flag : ", swing_flag)
            if swing_flag == 0: # left swing
                if angle_head < -80  and angle_head != 195 and angle_head != 230:
                    time.sleep(0.2)
                    self.check_flag(self.left_init_rotation_head_data, 230)
                    print("###### Left Init rotation head ######")
                elif -65 < angle_head < -55:
                    time.sleep(0.2)
                    self.check_flag(self.rigth_init_rotation_head_data, 230)
                    print(f"###### Rotation head: {self.get_angle_head()} ######")
                else:
                    time.sleep(0.2)
                    self.check_flag(self.left_rotation_head_data, 230)
                    print(f"###### Rotation head: {self.get_angle_head()} ######")
            
            elif swing_flag == 1: # right swing
                if 55 < angle_head < 66 and angle_head != 195 and angle_head != 230:
                    time.sleep(0.2)
                    self.check_flag(self.rigth_init_rotation_head_data, 230)
                    print("###### Right Init rotation head ######")
                else:
                    time.sleep(0.2)
                    self.check_flag(self.right_rotation_head_data, 230)
                    print(f"###### Rotation head: {self.get_angle_head()} ######")
            
        except Exception as e:
            print(e)
            print(traceback.format_exc())

    #-----------------------------------------------
    def walk_forward(self, distance):
        try:
            call_number = int(distance / 6)
            
            print("call_number", call_number)
            
            for i in range(call_number):
                print("step:", i+1)
                self.check_flag(11, 230)
                time.sleep(2)
                        
            self.check_flag(26, 230)
            
        except Exception as e:
            print(e)
            print(traceback.format_exc())
            return 0
        
    #-----------------------------------------------
    def turn_robot2theta(self, theta):
        print("turn theta : " ,theta)
        
        time_delay = 1
        if(theta<0):
            if theta > -20: theta = 1.9*(theta-2)
            else: theta = 1*(theta-2)

            theta = int(-theta)
            print(theta)
            turn_60 = theta//60
            temp_60 = theta % 60
            turn_45 = temp_60//45
            temp_45 = temp_60 % 45
            turn_20 = temp_45 // 20
            temp_20 = temp_45 % 20
            turn_10 = temp_20 // 10
            temp_10 = temp_20 % 10
            turn_5 = temp_10 // 5
            temp_5 = temp_10 % 5
            for i in range(turn_60):
                time.sleep(0.1)
                self.check_flag(19, 230)
                #print("turn_60_r", i)
                time.sleep(time_delay)
            for i in range(turn_45):
                time.sleep(0.1)
                self.check_flag(24, 230)
                time.sleep(time_delay)
                #print("turn_45_r", i)
            for i in range(turn_20):
                time.sleep(0.1)
                self.check_flag(9, 230)
                time.sleep(time_delay)
                #print("turn_20_r", i)      
            for i in range(turn_10):
                time.sleep(0.1)    
                self.check_flag(6, 230) 
                time.sleep(time_delay)
                #print("turn_10_r", i)
            for i in range(turn_5):
                time.sleep(0.1)
                self.check_flag(3, 230) 
                time.sleep(time_delay)
                #print("turn_5_r", i)
        else:
            theta = theta+2
            
            turn_60 = theta//60
            temp_60 = theta % 60
            turn_45 = temp_60//45
            temp_45 = temp_60 % 45
            turn_20 = temp_45 // 20
            temp_20 = temp_45 % 20
            turn_10 = temp_20 // 10
            temp_10 = temp_20 % 10
            turn_5 = temp_10 // 5
            temp_5 = temp_10 % 5
            for i in range(turn_60):
                time.sleep(0.1)
                self.check_flag(25, 230)
                time.sleep(time_delay)
                #print("turn_60_l", i)
            for i in range(turn_45):
                time.sleep(0.1)
                self.check_flag(22, 230)
                time.sleep(time_delay)
                #print("turn_45_l", i)
            for i in range(turn_20):
                time.sleep(0.1)
                self.check_flag(8, 230)
                time.sleep(time_delay)
                #print("turn_20_l", i)      
            for i in range(turn_10):
                time.sleep(0.1)    
                self.check_flag(4, 230) 
                time.sleep(time_delay)
                #print("turn_10_l", i)
            for i in range(turn_5):
                time.sleep(0.1)
                self.check_flag(1, 230) 
                time.sleep(time_delay)
                #print("turn_5_l", i)

        self.check_flag(30, 230) 
        
        
    def get_theta2dersired_point(self, a, b):
        theta = np.arctan2(a, b)
        theta = int(np.degrees(theta))
        return theta
        
    def swing_relation_distance(self, swing_flag, dis):
        
        if swing_flag : #right swing
            if dis < 23:
                return 44
                
            elif dis < 40:
                return 45

            else:
                return 46
                
        else:           #left swing
            if dis < 21:
                return 38
                
            elif dis < 42:
                return 39
            
            elif dis < 73:
                return 40
                
            elif dis < 85:
                return 41 
                
            else:
                return 2 #power 12
    
            
