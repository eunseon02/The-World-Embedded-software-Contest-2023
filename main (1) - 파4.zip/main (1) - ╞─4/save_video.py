import cv2
import time

# 웹캠 캡처 생성
cap = cv2.VideoCapture(0)  # 0은 웹캠 장치 번호입니다. 여러분의 시스템에 따라 다를 수 있습니다.

cap.set(3, 640)
cap.set(4, 480)
cap.set(5, 30)
time.sleep(0.5)

# 녹화 설정
fourcc = cv2.VideoWriter_fourcc(*'XVID')  # 코덱 설정 (XVID는 일반적으로 사용되는 코덱입니다)
out = cv2.VideoWriter('output.avi', fourcc, 20.0, (640, 480))  # 파일 이름, 코덱, 프레임 속도, 프레임 크기 설정

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # 프레임을 녹화
    out.write(frame)

    # 화면에 프레임 출력 (선택 사항)
    cv2.imshow('Recording', frame)

    # 'q' 키를 누르면 녹화 종료
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 종료 시 리소스 해제
cap.release()
out.release()
cv2.destroyAllWindows()
