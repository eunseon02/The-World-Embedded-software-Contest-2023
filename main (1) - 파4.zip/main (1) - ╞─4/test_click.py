import cv2
####
def extract_canny_edge(image):
    try:
        # Canny Edge Detection 적용
        edges = cv2.Canny(image, 50, 150)  # 최소와 최대 threshold 설정

        # 결과 표시
        cv2.imshow('Canny Edge Detection', edges)
        cv2.setMouseCallback('Canny Edge Detection', get_mouse_click)  # 'Canny Edge Detection' 창에 마우스 콜백 함수 등록
        cv2.waitKey(1)

    except Exception as e:
        print(e)

# 마우스 클릭 이벤트를 처리하는 함수
def get_mouse_click(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:  # 마우스 왼쪽 버튼 클릭 시
        print(f"Clicked at ({x}, {y})")

# 캠에서 이미지를 받아올 캡처 객체 생성
cap = cv2.VideoCapture(0)

while True:
    # 캠에서 프레임 읽기
    ret, frame = cap.read()

    # 프레임 출력
    cv2.imshow('Video Frame', frame)
    
    # 'Canny Edge Detection' 창에 대한 엣지 이미지 및 마우스 콜백 함수 처리
    extract_canny_edge(frame)
    
    # 'q' 키를 누르면 종료
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 캡처 객체와 윈도우 종료
cap.release()
cv2.destroyAllWindows()
