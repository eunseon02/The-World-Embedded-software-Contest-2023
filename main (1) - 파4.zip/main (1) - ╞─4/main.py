from detect import Detector
from minirobot_serial import MinirobotSerial
import time
import traceback

if __name__ == "__main__":
    try:
        end_flag = False
        isDebug = True
        
        waiting_time_loading = 2
        waiting_time_rotation = 1
        waiting_time_before = 0.1
        
        W_View_size = 640
        H_View_size = 480
        FPS = 30
        
        minirobot_serial = MinirobotSerial()
        while True:
            if isDebug: print("Wait Start Flag...")
            if minirobot_serial.RX_start_flag(): 
                minirobot_serial.check_flag(30, 230)
                break
        
        detector = Detector(isDebug, W_View_size, H_View_size, FPS)
        
        time.sleep(waiting_time_loading) 
        
        theta_ball = 0.0
        theta_pole = 0.0
        
        print("!-----Start Detect-----!")
        
        while True:
            print("--- First Ball Detect Start ---")
            
            miss_flag = 0
            while True:    
                #print("ball state queue length:", len(detector.ball_state_queue))
                            
                if detector.detect_ball():
                    print("!-----Detect Ball-----!")
                    theta_ball = minirobot_serial.get_angle_head()
                    break
                else:
                    print("!-----No Detect Ball-----!")
                    if len(detector.ball_state_queue) < detector.maxlen_state_queue: continue

                    
                    minirobot_serial.rotation_head(detector.swing_flag)
                    time.sleep(waiting_time_rotation)
    
            
            while True:
                print("pole state queue length:", len(detector.pole_state_queue))
                
                if detector.detect_pole():
                    print("!-----Detect Pole-----!")
                    theta_pole = minirobot_serial.get_angle_head()
                    break
                else:
                    print("!-----No Detect Pole-----!")
                    if len(detector.pole_state_queue) < detector.maxlen_state_queue: continue
                    
                    time.sleep(waiting_time_rotation)    
                    minirobot_serial.rotation_head(detector.swing_flag)
                    time.sleep(waiting_time_rotation)
            
            minirobot_serial.check_flag(29, 230) # head angle center
            
            print("theta_ball : ", theta_ball)
            print("theta_pole : ", theta_pole)
            
            detector.desired_point(False, theta_ball, theta_pole)
            print("swing_flag 1", detector.swing_flag)
            
            distance = detector.get_distance(detector.Desired_x, detector.Desired_y)
                
            # while True: pass
            
            # desired_point와의 각도 계산
            
            # 각도만큼 몸체 회전
            # minirobot_serial.check_flag(flag, 230)
            theta_Desired = minirobot_serial.get_theta2dersired_point(-detector.Desired_x, detector.Desired_y)
            minirobot_serial.turn_robot2theta(theta_Desired)
            time.sleep(waiting_time_rotation)
            
            if distance/5.5 > 12:
                print()
                distance = distance*6/10
                minirobot_serial.walk_forward(distance)
                time.sleep(waiting_time_rotation)
                print("continue")
                continue
            
            time.sleep(waiting_time_rotation*2)
            minirobot_serial.walk_forward(distance)
            time.sleep(waiting_time_rotation+1)
            
            # minirobot_serial.serial_port.flush()
            minirobot_serial.serial_port.flushInput()
            
            print("turn2 before")
            time.sleep(waiting_time_rotation*2)
            minirobot_serial.turn_robot2theta(-theta_Desired)
            time.sleep(waiting_time_rotation)
            print("turn2 after")
            
            # 오른쪽으로 돌면서 공 다시 찾기
            
            # 스윙 전 자세 조정
            
            time.sleep(waiting_time_rotation)
            minirobot_serial.check_flag(32, 230) # 머리 각도 최하로 내리기
            time.sleep(waiting_time_rotation)
            detector.isBall = False
            detector.isPole = False
            theta_pole = 0
            
            mode = 1
            while True:
                print("^^^^^^^^^////////////////^^^^^^^^^^^^^^^^^^^^mode:", mode)
                miss_flag = 0
                
                if mode == 0:
                    while True:
                        # if miss_flag > 50: break
                        if detector.detect_ball():
                            #print("!-----Detect Ball-----!")
                            mode = 1
                            break
                        else:
                            #print("!-----No Detect Ball-----!")
                            #miss_flag = miss_flag + 1
                            #print("miss_flag : ", miss_flag)
                            miss_flag += 1
                            if miss_flag > detector.maxlen_state_queue+1:
                                mode = -1
                                break
                        
                    if miss_flag > detector.maxlen_state_queue+1: 
                        time.sleep(waiting_time_before)
                        minirobot_serial.check_flag(30, 230)
                        mode = -1
                    
                    if mode == -1:
                        break
                    
                elif mode == 1:
                    time.sleep(waiting_time_before)
                    minirobot_serial.check_flag(32, 230) # 머리 각도 최하로 내리기
                    time.sleep(waiting_time_rotation)
                    #-------
                    if detector is not None:
                        new_maxlen_state_queue = 20
                        detector.change_ball_state_queue(new_maxlen_state_queue)
                        
                    
                    while True:
                        if detector.detect_pole():
                            if detector.is_arrow == 1:
                                print("arrow!!!!!!!!!!!!!!!!!!!!!1")
                                break
                        else:
                            print("break detect pole")
                            break
                            if len(detector.pole_state_queue) >= detector.maxlen_state_queue: break
                            
                    
                    """ratio = 0
                    while True:
                        if detector.detect_pole():
                            
                            print("detect pole")
                            x4 = detector.x4_pole
                            y4 = detector.y4_pole
                            w4 = detector.w4_pole
                            h4 = detector.h4_pole
                            
                            width = x4 - w4
                            height = y4 - h4
                            print("width : ", width)
                            print("height : ", height)
                            
                            if width > height:
                                ratio = height/width
                                
                            else:
                                ratio = width/height
                                
                        else:
                            print("break detect pole")
                            if len(detector.pole_state_queue) >= detector.maxlen_state_queue: break"""
                    
                    while True:
                        b = detector.detect_ball()
                        if detector.center_x_ball == -1 and detector.center_y_ball == -1:
                            mode = 0
                            break
                        if b:
                            flag, state = detector.adjust_ball_position()
                            time.sleep(waiting_time_before)
                            if flag != -1 and state == False:
                                minirobot_serial.check_flag(flag, 230)
                                time.sleep(waiting_time_rotation*2)
                                
                            if state == True:
                                mode = 2
                                print("~~~ detector.isHole ~~~", detector.isHole)
                                if detector.isHole == False: # IP detect
                                    #Desired point recalculate
                                    '''
                                    detector.desired_point_head_down(detector.center_x_ball, detector.center_y_ball, detector.center_x_pole, detector.center_y_pole)
                                    theta_Desired = minirobot_serial.get_theta2dersired_point(detector.Desired_y, -detector.Desired_x)
                                    if abs(theta_Desired) > 90: 
                                        if theta_Desired < 0: theta_Desired = 180 + theta_Desired
                                        else : theta_Desired = theta_Desired - 180
                                    elif 70 < abs(theta_Desired) < 90:
                                        if theta_Desired < 0: theta_Desired = 90 + theta_Desired
                                        else : theta_Desired = theta_Desired - 90
                                    minirobot_serial.turn_robot2theta(-theta_Desired)
                                    f abs(theta_Desired) < 6:
                                        mode = 3
                                    else:
                                        mode = 1
                                    '''
                                    
                                    mode = 2
                                    
                                else: # Hole detect
                                    while True:
                                        if detector.detect_pole(isRefind=True, mode=2):
                                            print("!-----Detect Pole-----!")
                                            theta_pole = minirobot_serial.get_angle_head()
                                            break
                                        else:
                                            print("!-----No Detect Pole-----!")
                                            if len(detector.pole_state_queue) < detector.maxlen_state_queue: continue
                                            
                                            time.sleep(waiting_time_rotation)
                                            minirobot_serial.rotation_head(detector.swing_flag)
                                            time.sleep(waiting_time_rotation)
                                    
                                    mode = 3
                                    
                                break
                        
                elif mode == 2:
                    time.sleep(waiting_time_rotation)
                    minirobot_serial.check_flag(30, 230) # 초기 머리 각도로 올리기
                    time.sleep(waiting_time_rotation)
                    minirobot_serial.check_flag(35, 230) # 초기 머리 각도로 올리기
                    time.sleep(waiting_time_rotation*2)
                    
                    for _ in range(10):
                        frame = detector.get_frame()
                    
                    
                    detector.clear_pole_buffer()

                    while True:
                        print("pole state queue length$%^&*:", len(detector.pole_state_queue))
                        
                        if detector.detect_pole(isRefind=True):
                            print("!-----Detect Pole-----!")
                            theta_pole = minirobot_serial.get_angle_head()
                            break
                        else:
                            print("!-----No Detect Pole-----!")
                            if len(detector.pole_state_queue) < detector.maxlen_state_queue: continue
                            
                            time.sleep(waiting_time_rotation)
                            minirobot_serial.rotation_head(detector.swing_flag)
                            time.sleep(waiting_time_rotation)
                            
                    detector.desired_point(True, 0, theta_pole)
                    print("!!swing_flag", detector.swing_flag)
                    
                    theta_Desired = minirobot_serial.get_theta2dersired_point(detector.Desired_y, -detector.Desired_x)
                    """if abs(theta_Desired) > 45: 
                        if theta_Desired < 0: theta_Desired = 90 + theta_Desired
                        else : theta_Desired = theta_Desired - 90"""
                        
                    if abs(theta_Desired) > 90: 
                        if theta_Desired < 0: theta_Desired = 180 + theta_Desired
                        else : theta_Desired = theta_Desired - 180
                    elif 70 < abs(theta_Desired) < 90:
                        if theta_Desired < 0: theta_Desired = 90 + theta_Desired
                        else : theta_Desired = theta_Desired - 90
                    minirobot_serial.turn_robot2theta(-theta_Desired)
                    
                    if abs(theta_Desired) < 6:
                        mode = 3
                    else:
                        mode = 1
                    
                elif mode == 3:
                    print("mode:", mode)
                    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ detector.isHole ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~:", detector.isHole)
                    time.sleep(waiting_time_rotation)
                    dist = detector.distance2pole
                    print("dist : ", dist)
                    swing_power = minirobot_serial.swing_relation_distance(detector.swing_flag, dist)
                    print("swing_power : ", swing_power)
                    minirobot_serial.check_flag(swing_power, 230)
                    if detector.swing_flag == 0:
                        time.sleep(7)
                        minirobot_serial.serial_port.flushInput()
                        minirobot_serial.check_flag(22, 230) #left turn 45
                        time.sleep(0.5)
                        minirobot_serial.check_flag(8, 230) #left turn 20
                        time.sleep(0.5)
                        minirobot_serial.check_flag(29, 230)
                        time.sleep(0.5)
                        
                    elif detector.swing_flag == 1:
                        time.sleep(7)
                        minirobot_serial.serial_port.flushInput()
                        minirobot_serial.check_flag(24, 230) #right turn 45
                        time.sleep(0.5)
                        minirobot_serial.check_flag(9, 230) #right turn 20
                        time.sleep(0.5)
                        minirobot_serial.check_flag(29, 230)
                        time.sleep(0.5)
                    
                    if detector.isHole == True:
                        while True:
                            if detector.detect_ball():
                                print("!-----isHole Detect Ball-----!")
                                
                                break
                            else:
                                print("!-----isHole No Detect Ball-----!")
                                if len(detector.ball_state_queue) < detector.maxlen_state_queue: continue

                                minirobot_serial.rotation_head(detector.swing_flag)
                                time.sleep(waiting_time_rotation)

                        while True:
                            if detector.detect_pole(isRefind=True):
                                print("!-----isHole Detect Pole-----!")
                                
                                break
                            else:
                                print("!-----isHole No Detect Pole-----!")
                                if len(detector.pole_state_queue) < detector.maxlen_state_queue: continue
                                
                                time.sleep(waiting_time_rotation)
                                minirobot_serial.rotation_head(detector.swing_flag)
                                time.sleep(waiting_time_rotation)
                        
                        end_flag = detector.get_end_flag()
                        detector.isHole = False
                        break
                        
                detector.isBall = False
                detector.isPole = False
                 
                    
    
            
            """
            while True:
                miss_flag = 0
                
                while True:
                    # if miss_flag > 50: break
                    if detector.detect_ball():
                        print("!-----Detect Ball-----!")
                        break
                    else:
                        print("!-----No Detect Ball-----!")
                        #miss_flag = miss_flag + 1
                        #print("miss_flag : ", miss_flag)
                        miss_flag += 1
                        print("miss_flag", miss_flag)
                        if miss_flag > 100: break
                
                #if miss_flag > 45: break
                if miss_flag > 100: 
                    time.sleep(0.1)
                    minirobot_serial.check_flag(30, 230)
                    break
                
                flag, state = detector.adjust_ball_position()
                time.sleep(waiting_time_rotation)
                if flag != -1 and state == False:
                    minirobot_serial.check_flag(flag, 230)
                
                if state:
                    time.sleep(waiting_time_rotation)
                    minirobot_serial.check_flag(30, 230) # 초기 머리 각도로 올리기
                    time.sleep(0.5)
                    minirobot_serial.check_flag(35, 230)
                    while True:
                        print("pole state queue length:77777", len(detector.pole_state_queue))
                        
                        if detector.detect_pole(isRefine=True):
                            print("!-----Detect Pole-----!")
                            theta_pole = minirobot_serial.get_angle_head()
                            print("theta_pole : ", theta_pole)
                            break
                        else:
                            print("!-----No Detect Pole-----!")
                            if len(detector.pole_state_queue) < detector.maxlen_state_queue: continue
                            
                            minirobot_serial.rotation_head()
                            time.sleep(waiting_time_rotation)
                            
                    detector.desired_point(True, 0, theta_pole)
                        
                    theta_Desired = minirobot_serial.get_theta2dersired_point(detector.Desired_y, -detector.Desired_x)
                    if abs(theta_Desired) > 90: 
                        if theta_Desired < 0: theta_Desired = 180 + theta_Desired
                        else : theta_Desired = theta_Desired - 180
                    minirobot_serial.turn_robot2theta(-theta_Desired)
                    
                    time.sleep(waiting_time_rotation)
                    minirobot_serial.check_flag(2, 230) # swing
                    
                    time.sleep(waiting_time_rotation*2)
                    print("!!! after swing !!!")
                    minirobot_serial.turn_robot2theta(90)
                    break
            """
                    
            miss_flag = 0
            detector.isBall = False
            detector.isPole = False
            
            if end_flag:
                minirobot_serial.check_flag(47, 230)
                time.sleep(waiting_time_rotation*2)
                
                print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                print("~~~~~ Goal ~~~~~")
                print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
                break
        
    except Exception as e:
        print(e)
        print(traceback.format_exc())
