import cv2
import numpy as np
import math
from collections import deque
import cv2
import time
import traceback

class Detector():
    def __init__(self, isDebug=False, W_View_size=640, H_View_size=480, FPS=60) -> None:
        
        ################## CV2 ####################
        
        self.isDebug = isDebug
        self.W_View_size = W_View_size
        self.H_View_size = H_View_size
        self.FPS = FPS
        self.frame = None
        self.is_arrow = 0

        self.cap = cv2.VideoCapture(0)
        
        if self.cap.isOpened(): 
            print('The camera is successfully connected.')
        else:
            print('Failed to connect to the camera.')
        
        self.cap.set(3, self.W_View_size)
        self.cap.set(4, self.H_View_size)
        self.cap.set(5, self.FPS)
        time.sleep(0.5)

        if self.isDebug:
            cv2.namedWindow("cam")
            cv2.namedWindow("result_frame")
            cv2.namedWindow("mask_ball")
            cv2.namedWindow("mask_pole")

            cv2.moveWindow("cam", 0, 0)
            cv2.moveWindow("result_frame", 0, self.H_View_size*2+15)
            cv2.moveWindow("mask_ball", self.W_View_size+15, 35)
            cv2.moveWindow("mask_pole", self.W_View_size*2+15, 35)

            black_image = np.zeros((self.H_View_size, self.W_View_size, 3), np.uint8)

            cv2.imshow("cam", black_image)
            cv2.imshow("result_frame", black_image)
            cv2.imshow("mask_ball", black_image)
            cv2.imshow("mask_pole", black_image)
            cv2.waitKey(1000)
            
        ###########################################
        
        self.hsv_ball_lower, self.hsv_ball_upper, self.yuv_ball_lower, self.yuv_ball_upper \
            = (117, 80, 174), (191, 186, 255), (102, 100, 150), (211, 178, 213)
        
        self.hsv_pole_lower, self.hsv_pole_upper, self.yuv_pole_lower, self.yuv_pole_upper \
            = (20, 80, 201), (67, 136, 255), (190, 63, 102), (219, 102, 165)

        
        ############## object point ###############
        self.maxlen_state_queue = 20
        
        self.center_x_ball = -1
        self.center_y_ball = -1
        self.ball_state_queue = deque(maxlen=self.maxlen_state_queue)
        self.isBall = False
        
        self.center_x_pole = -1
        self.center_y_pole = -1
        self.pole_state_queue = deque(maxlen=self.maxlen_state_queue)
        self.isPole = False
        
        self.distance2pole = -1
        
        self.hole_size_queue = deque(maxlen=self.maxlen_state_queue)
        self.isHole = False
        ###########################################
        
        ############## desired point ###############
        self.homography_matrix = np.array([[-4.82086446e-01,  1.48273383e-02,  1.41722750e+02],
                                            [-1.11879902e-02, -1.76854804e-01,  2.78719601e+02], 
                                            [-3.61976908e-05,  1.32346810e-02,  1.00000000e+00]])
                                           
        ###########################################
        
        ############## desired point ###############
        
        self.adjust_left_min_x = 360
        self.adjust_left_max_x = 360 + 25
        self.adjust_left_min_y = 230 - 30
        self.adjust_left_max_y = 230 + 30
        
        self.adjust_right_min_x = 410 - 25
        self.adjust_right_max_x = 410 + 25
        self.adjust_right_min_y = 230 - 30
        self.adjust_right_max_y = 230 + 30
        
        ###########################################
        
        self.swing_flag = 0
        
    #-----------------------------------------------
    
    def get_frame(self, isDebug=False):
        grab, frame = self.cap.read()
        if not grab:
            raise Exception("Could not grab next frame. [EOF or Device is lost]")
            
        if isDebug:
            cv2.imshow('cam', frame)

        return frame
    
    #-----------------------------------------------
    
    def detect_ball(self) -> bool:
        
        try:                
            if len(self.ball_state_queue) == self.maxlen_state_queue:
                self.ball_state_queue.clear()
            
            frame = self.get_frame(self.isDebug)
            
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            yuv = cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)
            
            hsv_Lower = np.array(self.hsv_ball_lower)
            hsv_Upper = np.array(self.hsv_ball_upper)
            yuv_Lower = np.array(self.hsv_ball_lower)
            yuv_Upper = np.array(self.hsv_ball_upper)
            
            hsv_mask = cv2.inRange(hsv, hsv_Lower, hsv_Upper)
            yuv_mask = cv2.inRange(yuv, yuv_Lower, yuv_Upper)
            
            mask = cv2.bitwise_or(hsv_mask, yuv_mask)
            
            mask = self.find_nearest_edge_length(frame, mask)
            
            cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
            
            mask_ball = np.zeros((self.H_View_size, self.W_View_size, 3), np.uint8)
            
            cv2.drawContours(mask_ball, cnts, -1, (255, 255, 255), 2)
            
            if self.isDebug:
                cv2.imshow("mask_ball", mask_ball)
                cv2.waitKey(1)
            
            if len(cnts) > 0:
                c = max(cnts, key=cv2.contourArea)
                
                area = cv2.contourArea(c)
                
                print("ball area:", area)
                print("ball area:", area)
                
                if 200 < area:
                    x4, y4, w4, h4 = cv2.boundingRect(c)
                    
                    self.x4_ball = x4
                    self.y4_ball = y4
                    self.w4_ball = w4
                    self.h4_ball = h4
                    
                    self.center_x_ball = int(self.x4_ball + self.w4_ball / 2)
                    self.center_y_ball = int(self.y4_ball + self.h4_ball / 2)
                    
                    if self.isDebug:
                        arrow_start = (self.W_View_size//2, 231)
                        arrow_end_top = (arrow_start[0], arrow_start[1] - 10)
                        arrow_end_bottom = (arrow_start[0], arrow_start[1] + 10)
                        arrow_end_left = (arrow_start[0] - 10, arrow_start[1])
                        arrow_end_right = (arrow_start[0] + 10, arrow_start[1])
                        
                        cv2.arrowedLine(frame, arrow_start, arrow_end_top, (255, 102, 153), 1)
                        cv2.arrowedLine(frame, arrow_start, arrow_end_bottom, (255, 102, 153), 1)
                        cv2.arrowedLine(frame, arrow_start, arrow_end_left, (255, 102, 153), 1)
                        cv2.arrowedLine(frame, arrow_start, arrow_end_right, (255, 102, 153), 1)
                        
                        cv2.rectangle(frame, 
                            (self.x4_ball, self.y4_ball), 
                            (self.x4_ball + self.w4_ball, self.y4_ball + self.h4_ball), 
                            (0, 0, 255), 
                            2)
                            
                        cv2.rectangle(frame, 
                            (self.adjust_left_min_x, self.adjust_left_min_y), 
                            (self.adjust_left_max_x, self.adjust_left_max_y), 
                            (255, 255, 255), 
                            2)
                            
                        cv2.rectangle(frame, 
                            (self.adjust_right_min_x, self.adjust_right_min_y), 
                            (self.adjust_right_max_x, self.adjust_right_max_y), 
                            (0, 0, 0), 
                            2)
                        
                        desired_center_x = self.W_View_size // 2 # 320
                        desired_center_y = 231
                        cv2.circle(frame, (desired_center_x, desired_center_y), 1, (255, 255, 255), -1)
                        
                        cv2.circle(frame, (self.center_x_ball, self.center_y_ball), 3, (200, 255, 92), -1)
                        
                        cv2.imshow("result_frame", frame)
                        cv2.waitKey(10)
                    
                    self.ball_state_queue.append(True)
                    
                    ball_true_percentage = 0.0
                    if len(self.ball_state_queue) == self.maxlen_state_queue:
                        ball_true_percentage = sum(self.ball_state_queue) / len(self.ball_state_queue) * 100
                        print("ball_true_percentage: ", ball_true_percentage)
                        
                    if ball_true_percentage >= 25.0:
                        self.isBall = True
                    else:
                        self.isBall = False
                    
                else:
                    self.x4_ball = -1
                    self.y4_ball = -1
                    self.w4_ball = -1
                    self.h4_ball = -1
                    
                    self.center_x_ball = -1
                    self.center_y_ball = -1
                    
                    self.ball_state_queue.append(False)
                    
            else:
                self.x4_ball = -1
                self.y4_ball = -1
                self.w4_ball = -1
                self.h4_ball = -1
                
                self.center_x_ball = -1
                self.center_y_ball = -1
                
                self.ball_state_queue.append(False)
                    
            return self.isBall
            
        except Exception as e:
            print(e)
            print(traceback.format_exc())

    #-----------------------------------------------  
    def detect_pole(self, isRefind=False, mode=0) -> bool:
        self.is_arrow = 0
    
        try:
                
            if len(self.pole_state_queue) >= self.maxlen_state_queue:
                self.pole_state_queue.clear()
                self.hole_size_queue.clear()
                
            frame = self.get_frame(self.isDebug)
            
            hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
            yuv = cv2.cvtColor(frame, cv2.COLOR_BGR2YUV)
                
            hsv_Lower = self.hsv_pole_lower
            hsv_Upper = self.hsv_pole_upper
            
            yuv_Lower = self.yuv_pole_lower
            yuv_Upper = self.yuv_pole_upper
            
            hsv_mask = cv2.inRange(hsv, hsv_Lower, hsv_Upper)
            yuv_mask = cv2.inRange(yuv, yuv_Lower, yuv_Upper)
            
            mask = cv2.bitwise_and(hsv_mask, yuv_mask)
            
            mask = self.find_nearest_edge_length(frame, mask)
            
            cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
            
            
            mask_pole = np.zeros((self.H_View_size, self.W_View_size, 3), np.uint8)
            
            result_image = frame.copy()
            
            leftmost_edge = float('inf')
            rightmost_edge = -1
            for contour in cnts:
                leftmost_point = tuple(contour[contour[:, :, 0].argmin()][0])
                rightmost_point = tuple(contour[contour[:, :, 0].argmax()][0])
                
                if leftmost_point[0] < leftmost_edge:
                    leftmost_edge = leftmost_point[0]
                    
                if rightmost_point[0] > rightmost_edge:
                    rightmost_edge = rightmost_point[0]
                
                edge_length = rightmost_edge - leftmost_edge
                
                print("edge_leng", edge_length)


            
            
            circle_image = frame.copy()
            for contour in cnts:
                perimeter = cv2.arcLength(contour, True)
                
                
                
                epsilon = 0.04 * perimeter
                approx = cv2.approxPolyDP(contour, epsilon, True)
                
                
                print("approx", len(approx))
                if len(approx) >= 8:
                    print("it is pole")
                    
                else:
                    print("it is arrow")
                    self.is_arrow = 1
            
            #cv2.imshow('circle_img', circle_image)
            
            #gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            #cv2.imshow('Circle Detection11', gray)
            #circles = cv2.HoughCircles(gray,cv2.HOUGH_GRADIENT, dp=1, minDist=20, param1=50, param2=30, minRadius=0,maxRadius= 600)
            #if circles is not None:
            #    circles = np.uint16(np.around(circles))
            #    for circle in circles[0, :]:
            #        center = (circle[0], circle[1])  # 원 중심 좌표
            #        radius = circle[2] 
            #        cv2.circle(frame, center, radius, (0, 255, 0), 2)
            #    cv2.imshow('Circle Detection', frame)
            #    cv2.waitKey(0)
            
            
            cv2.drawContours(mask_pole, cnts, -1, (255, 255, 255), 2)
            
            
            if self.isDebug:
                cv2.imshow("mask_pole", mask_pole)
                cv2.waitKey(10)
            
            if len(cnts) > 0:
                
                '''
                distance_list = []
                for c in cnts:
                    x4, y4, w4, h4 = cv2.boundingRect(c)
                
                    center_x_pole = int(x4 + w4 / 2)
                    center_y_pole = int(y4 + h4 / 2)
                    
                    dis = np.linalg.norm(np.array([center_x_pole, center_y_pole]) - np.array([self.center_x_ball, self.center_y_ball]))
                    if dis < 180:
                        distance_list.append(dis)
                        
                if not distance_list:
                    self.pole_state_queue.append(False)
                    return
                
                print("distance_list:", distance_list)

                cnt_index = np.argmax(distance_list)
                
                
                area = cv2.contourArea(cnts[cnt_index])
                '''
                
                # c = max(cnts, key=cv2.contourArea)
                c = min(cnts, key=lambda c: cv2.boundingRect(c)[1])
                
                area = cv2.contourArea(c)
                
                print("pole area:", area)
                
                if 125 < area:
                    x4, y4, w4, h4 = cv2.boundingRect(c)
                    
                    self.x4_pole = x4
                    self.y4_pole = y4
                    self.w4_pole = w4
                    self.h4_pole = h4
                    
                    self.center_x_pole = int(self.x4_pole + self.w4_pole / 2)
                    self.center_y_pole = int(self.y4_pole + self.h4_pole / 2)

                    if self.isDebug:                        
                        cv2.rectangle(frame, 
                            (self.x4_pole, self.y4_pole), 
                            (self.x4_pole + self.w4_pole, self.y4_pole + self.h4_pole), 
                            (0, 255, 0), 
                            2)
                        
                        cv2.circle(frame, (self.center_x_pole, self.center_y_pole), 3, (255, 0, 255), -1)
                        
                        cv2.imshow("result_frame", frame)
                        cv2.waitKey(1)
                        
                    self.pole_state_queue.append(True)
                    self.hole_size_queue.append(edge_length)
                    print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@2")
                    print("pole_state_queue", len(self.pole_state_queue))
                    
                    pole_true_percentage = 0.0
                    if len(self.pole_state_queue) == self.maxlen_state_queue:
                        pole_true_percentage = sum(self.pole_state_queue) / len(self.pole_state_queue) * 100
                        print("pole_true_percentage:", pole_true_percentage)
                        
                        if max(self.hole_size_queue) > 100 and mode == 2:
                            self.isHole = True
                        else:
                            self.isHole = False
                        
                    if pole_true_percentage >= 25.0:
                        self.isPole = True
                    else:
                        self.isPole = False
                else:
                    self.x4_pole = -1
                    self.y4_pole = -1
                    self.w4_pole = -1
                    self.h4_pole = -1
                    
                    self.center_x_pole = -1
                    self.center_y_pole = -1
                    
                    self.pole_state_queue.append(False)
                    
            else:
                self.x4_pole = -1
                self.y4_pole = -1
                self.w4_pole = -1
                self.h4_pole = -1
                
                self.center_x_pole = -1
                self.center_y_pole = -1
                
                self.pole_state_queue.append(False)
            
            return self.isPole
        
        except Exception as e:
            print(e)
            print(traceback.format_exc())
       
    #-----------------------------------------------
        
    def find_nearest_edge_length(self, frame, mask):
        try:
            edges = cv2.Canny(frame, 50, 150)
            
            expanded_mask = mask.copy()  # 마스크 복사
            
            # 마스크를 주변으로 팽창(dilation)하여 확장
            kernel = np.ones((5, 5), np.uint8)
            expanded_mask = cv2.dilate(expanded_mask, kernel, iterations=3)  # 주변으로 5번 팽창
            
            mask_from_edges = np.zeros_like(expanded_mask)            
            
            mask_from_edges = np.where((expanded_mask == 255) & (edges == 255), 255, mask_from_edges)
            
            mask_from_edges = mask_from_edges.astype(np.uint8)
            
            kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (7,7))
            mask_from_edges = cv2.dilate(mask_from_edges, kernel)
            
            return mask_from_edges

        except Exception as e:
            print(e)
            print(traceback.format_exc())
        
    #-----------------------------------------------  

    def desired_point(self, isRefind, theta_ball, theta_pole):
        # try:
            L = 13.5 # 공과 로봇 사이의 스윙 최적 거리
            
            if isRefind == False: 
                ball_x, ball_y = self.transform_point(self.homography_matrix, self.center_x_ball, self.center_y_ball)
                pole_x, pole_y = self.transform_point(self.homography_matrix, self.center_x_pole, self.center_y_pole)
            else:
                ball_x, ball_y = np.array([0, 13.5])
                pole_x, pole_y = self.transform_point(self.homography_matrix, self.center_x_pole, self.center_y_pole)
                
            print("ball real:", ball_x, ball_y)
            print("pole real:", pole_x, pole_y)
            
            Ball_x, Ball_y = -ball_x, ball_y
            Pole_x, Pole_y = -pole_x, pole_y
            
            Ball_x, Ball_y = self.head_theta_trans(Ball_x, Ball_y, theta_ball)
            Pole_x, Pole_y = self.head_theta_trans(Pole_x, Pole_y, theta_pole)
            
            self.distance2pole = math.sqrt(Pole_x ** 2 + Pole_y ** 2)
            print("dist_pole : ", self.distance2pole)
            
            #Pole과 Ball의 X좌표 크기 비교
            if Ball_x != Pole_x:
                Py_By = Pole_y - Ball_y
                Px_Bx = Pole_x - Ball_x

                Desired_x1 = L*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_x
                Desired_y1 = L*((Px_Bx)/(Ball_y - Pole_y))*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_y
                dist1 = math.sqrt(Desired_x1 ** 2 + Desired_y1 ** 2)
                print("Desired_x1 : ", Desired_x1)
                print("Desired_y1 : ", Desired_y1)
                
                Desired_x2 = (-1)*L*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_x
                Desired_y2 = (-1)*L*((Px_Bx)/(Ball_y - Pole_y))*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_y
                dist2 = math.sqrt(Desired_x2 ** 2 + Desired_y2 ** 2)
                print("Desired_x2 : ", Desired_x2)
                print("Desired_y2 : ", Desired_y2)

                if dist1 < dist2:
                    self.Desired_x = Desired_x1
                    self.Desired_y = Desired_y1
                    #self.swing_flag = 1
                else:
                    self.Desired_x = Desired_x2
                    self.Desired_y = Desired_y2
                    #if not(isRefind): self.swing_flag = 1
                    #self.swing_flag = 0
                
                if isRefind:
                    if Pole_x > self.Desired_x:
                        self.swing_flag = 1
                    else:
                        self.swing_flag = 0

            else:
                self.Desired_x = Ball_x - L
                self.Desired_y = Ball_y
            
            print("swing_flag:", self.swing_flag)
            
            if self.isDebug:
                H_map_size = 200
                W_map_size = 300
                
                birdeye_view_image = np.full((H_map_size, W_map_size, 3), 150, np.uint8)
                
                arrow_start = (W_map_size//2, H_map_size - 5)
                arrow_end_top = (arrow_start[0], arrow_start[1] - 10)
                arrow_end_left = (arrow_start[0] - 10, arrow_start[1])
                arrow_end_right = (arrow_start[0] + 10, arrow_start[1])
                
                cv2.arrowedLine(birdeye_view_image, arrow_start, arrow_end_top, (0, 0, 0), 1)
                cv2.arrowedLine(birdeye_view_image, arrow_start, arrow_end_left, (0, 0, 0), 1)
                cv2.arrowedLine(birdeye_view_image, arrow_start, arrow_end_right, (0, 0, 0), 1)
                
                print("ball1:", Ball_x, Ball_y)
                print("pole1:", Pole_x, Pole_y)
                print("desired1:", self.Desired_x, self.Desired_y)
                
                #print("image_ball:", int(Ball_x+W_map_size//2), int(H_map_size-Ball_y))
                #print("image_pole:", int(Pole_x+W_map_size//2), int(H_map_size-Pole_y))
                #print("image_desired:", int(self.Desired_x+W_map_size//2), int(H_map_size-self.Desired_y))
                
                image_ball_x = int(Ball_x+W_map_size//2)
                image_ball_y = int(H_map_size-Ball_y)
                image_pole_x = int(Pole_x+W_map_size//2)
                image_pole_y = int(H_map_size-Pole_y)
                image_desired_x = int(self.Desired_x+W_map_size//2)
                image_desired_y = int(H_map_size-self.Desired_y)
                
                cv2.circle(birdeye_view_image, (image_ball_x, image_ball_y), 2, (0, 0, 255), -1)
                cv2.circle(birdeye_view_image, (image_pole_x, image_pole_y), 2, (0, 255, 0), -1)
                cv2.circle(birdeye_view_image, (image_desired_x, image_desired_y), 2, (255, 0, 0), -1)
                
                birdeye_view_image = cv2.resize(birdeye_view_image, (2*W_map_size, 2*H_map_size), interpolation=cv2.INTER_LINEAR)
                
                cv2.imshow("birdeye_view", birdeye_view_image)
                cv2.waitKey(2000)
                
            
        #except Exception as e:
         #   print(e)
          #  print(traceback.format_exc())
    def desired_point_head_down(self, bx, by, px, py):
        # try:
            L = 13.5 # 공과 로봇 사이의 스윙 최적 거리
            
            #Pole과 Ball의 X좌표 크기 비교
            Ball_x = bx
            Ball_y = 320 - by
            
            Pole_x = px
            Pole_y = 320 - py
            
            if Ball_x != Pole_x:
                Py_By = Pole_y - Ball_y
                Px_Bx = Pole_x - Ball_x

                Desired_x1 = L*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_x
                Desired_y1 = L*((Px_Bx)/(Ball_y - Pole_y))*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_y
                dist1 = math.sqrt(Desired_x1 ** 2 + Desired_y1 ** 2)
                print("Desired_x1 : ", Desired_x1)
                print("Desired_y1 : ", Desired_y1)
                
                Desired_x2 = (-1)*L*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_x
                Desired_y2 = (-1)*L*((Px_Bx)/(Ball_y - Pole_y))*(np.abs(Py_By)/np.sqrt(np.power(Py_By, 2)+np.power(Px_Bx, 2)))+Ball_y
                dist2 = math.sqrt(Desired_x2 ** 2 + Desired_y2 ** 2)
                print("Desired_x2 : ", Desired_x2)
                print("Desired_y2 : ", Desired_y2)

                if dist1 < dist2:
                    self.Desired_x = Desired_x1
                    self.Desired_y = Desired_y1
                    #self.swing_flag = 1
                else:
                    self.Desired_x = Desired_x2
                    self.Desired_y = Desired_y2
                    #if not(isRefind): self.swing_flag = 1
                    #self.swing_flag = 0
                
                if Pole_x > self.Desired_x:
                        self.swing_flag = 1
                else:
                    self.swing_flag = 0

            else:
                self.Desired_x = Ball_x - L
                self.Desired_y = Ball_y
            
            print("swing_flag:", self.swing_flag)
            
    #-----------------------------------------------
    
    def get_distance(self, x, y):
        distance = math.sqrt(x**2 +  y** 2)
        return distance
    
    #-----------------------------------------------
    
    def adjust_ball_position(self):
        # 공의 위치를 가져와서 조정하는 로직 추가
        center_x = self.center_x_ball
        center_y = self.center_y_ball
        print("center_x : ", center_x)
        print("center_y : ", center_y)
        
        if center_x == -1 and center_y == -1:
            return -1, False
            
        if self.swing_flag == 0:
            desired_center_x = 360
            desired_center_y = 231
        
            if (self.adjust_left_min_x < center_x < self.adjust_left_max_x) and (self.adjust_left_min_y < center_y < self.adjust_left_max_y):
                # 스윙
                return 2, True

            if self.adjust_left_min_x < center_x < self.adjust_left_max_x : 
                if center_y > desired_center_y: 
                    #앞으로 이동 
                    return 31, False
                
                elif center_y < desired_center_y:
                    #go forward
                    return 27, False
            elif self.adjust_left_min_y < center_y < self.adjust_left_max_y:
                if center_x > desired_center_x:
                    # 오른쪽으로 이동
                    return 20, False
                elif center_x < desired_center_x:
                    #왼쪽으로 이동
                    return 15, False
            else :
                if center_y > desired_center_y: 
                    #앞으로 이동 
                    return 31, False
                
                elif center_y < desired_center_y:
                    #go forward
                    return 27, False
        
        elif self.swing_flag == 1:
            desired_center_x = 410
            desired_center_y = 231
            
            if (self.adjust_right_min_x < center_x < self.adjust_right_max_x) and (self.adjust_right_min_y < center_y < self.adjust_right_max_y):
                # 스윙
                return 2, True

            if self.adjust_right_min_x < center_x < self.adjust_right_max_x : 
                if center_y > desired_center_y: 
                    #앞으로 이동 
                    return 31, False
                
                elif center_y < desired_center_y:
                    #go forward
                    return 27, False
            elif self.adjust_right_min_y < center_y < self.adjust_right_max_y:
                if center_x > desired_center_x:
                    # 오른쪽으로 이동
                    return 20, False
                elif center_x < desired_center_x:
                    #왼쪽으로 이동
                    return 15, False
            else :
                if center_y > desired_center_y: 
                    #앞으로 이동 
                    return 31, False
                
                elif center_y < desired_center_y:
                    #go forward
                    return 27, False
        
    #-----------------------------------------------
    
    def head_theta_trans(self, x, y, theta):
        theta = -theta
        
        cos_theta = np.cos(np.pi/180 * theta)
        sin_theta = np.sin(np.pi/180 * theta)
        
        goal_x = x * cos_theta - y * sin_theta
        goal_y = x * sin_theta + y * cos_theta

        #rotation_matrix_z = np.array([np.cos(theta), -np.sin(theta)],
        #                            [np.sin(theta), np.cos(theta)])

        #vector = np.array([x, y])
        #rotated_vector_z = np.dot(rotation_matrix_z, vector)

        return goal_x, goal_y
    
    #-----------------------------------------------
    
    def transform_point(self, homography_matrix, center_x, center_y):
        # 입력된 center_x, center_y를 평면 2의 좌표로 변환
        input_point = np.array([[center_x, center_y]], dtype=np.float32)
        transformed_point = cv2.perspectiveTransform(input_point.reshape(-1, 1, 2), homography_matrix)

        # 변환된 좌표를 반환
        return transformed_point[0][0]
    
    #-----------------------------------------------
    
    def distance_to_line(self, x1, y1, x2, y2, x, y):
        # (x1, y1)에서 (x2, y2)를 지나는 직선을 표현하는 방정식의 계수 계산
        a = y2 - y1
        b = x1 - x2
        c = (x1 * y2) - (x2 * y1)
        slope = a/b
        
        # 선분의 길이 계산
        length = math.sqrt(slope**2 + 1)
        
        # 점 (x, y)에서 직선까지의 거리 계산
        distance = abs((slope * x + y + c) / length)
        
        return distance
    
    #-----------------------------------------------
    def clear_pole_buffer(self):
        if len(self.pole_state_queue) >= self.maxlen_state_queue:
                self.pole_state_queue.clear()

    def get_end_flag(self):
        print("$$$$$$$$$$$")
        print("abs(self.center_x_ball - self.center_x_pole):", abs(self.center_x_ball - self.center_x_pole))
        print("abs(self.center_y_ball - self.center_y_pole):", abs(self.center_y_ball - self.center_y_pole))
        print("$$$$$$$$$$$")
        
        if abs(self.center_x_ball - self.center_x_pole) < 80 and abs(self.center_y_ball - self.center_y_pole) < 80:
            return True
        else:
            return False

    def __del__(self):
        self.cap.release()
        cv2.destroyAllWindows()
    
    def change_ball_state_queue(self, new_maxlen_state_queue):
        self.maxlen_state_queue = new_maxlen_state_queue
        self.ball_state_queue = deque(maxlen=self.maxlen_state_queue)
        
    #-----------------------------------------------
